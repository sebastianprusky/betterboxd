SYNTHETIC TEST DATA — contains no real Letterboxd account information.
Comfort & Blockbuster Fan
Warm, accessible taste favoring comedy, adventure, family films, and crowd-pleasers.
160 ratings; 195 watched; 120 diary entries; 80 reviews; 45 watchlist titles; 35 liked films.
Ratings and review text are deterministic test fixtures derived from public MovieLens movie metadata.