SYNTHETIC TEST DATA — contains no real Letterboxd account information.
Midnight Genre Fan
Strong preference for horror, science fiction, thrillers, fantasy, and animation.
160 ratings; 195 watched; 120 diary entries; 80 reviews; 45 watchlist titles; 33 liked films.
Ratings and review text are deterministic test fixtures derived from public MovieLens movie metadata.